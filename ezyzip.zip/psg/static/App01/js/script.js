let navBar = document.querySelector("nav")
document.querySelector("#menu-btn").onclick = () => {
    navBar.classList.toggle("active")
    searchForm.classList.remove("active")
    cart.classList.remove("active")
}

let cart = document.querySelector(".cart-items-container")
document.querySelector("#cart-btn").onclick = () => {
    cart.classList.toggle("active")
    searchForm.classList.remove("active")
    navBar.classList.remove("active")
}

let searchForm = document.querySelector(".search-form")
document.querySelector("#search-btn").onclick = () => {
    searchForm.classList.toggle("active")
    cart.classList.remove("active")
    navBar.classList.remove("active")
}


// calculate the total price of items in the cart
let updateTotal = () => {
    let cartItems = document.querySelectorAll(".cart-item")
    let totalElement = cart.querySelector(".total-price")
    let total = 0;
    cartItems.forEach(item => {
        let priceElement = item.querySelector(".price")
        let quantity = item.querySelector(".item-quantity").value
        let itemTotal = item.querySelector(".total-item")

        let price = parseFloat(priceElement.innerHTML)
        itemTotal.innerHTML = (quantity * price).toFixed(2)
        total += price * quantity
    })
    total = total.toFixed(2)
    totalElement.innerHTML = total
}
updateTotal();


// Remove items from cart shopping
let removeItem = () => {
    let carRemove_btns = document.querySelectorAll(".remove")
    carRemove_btns.forEach((btn) => {
        btn.addEventListener("click", (event) => {
            event.target.parentElement.remove();
            itemsAdded = itemsAdded.filter(item => item.productTitle != event.target.parentElement.querySelector('.cart-product-title').innerHTML)
            updateTotal();
        });
    })
}
removeItem()


// calculate the total price of item if quantity found
let calculateQuantity = () => {
    let itemQuantity = cart.querySelectorAll(".item-quantity")
    itemQuantity.forEach(item => {
        item.addEventListener("change", () => {
            if (isNaN(item.value) || item.value <= 0) {
                item.value = 1
            }
            item.value = Math.floor(item.value)
            updateTotal()
        })
    })
}
calculateQuantity()


// add to cart
let addBtns = document.querySelectorAll(".add-cart")
let itemsAdded = [];

addBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        let product = btn.parentElement;
        let productTitle = product.querySelector(".product-title").innerHTML
        let productPrice = product.querySelector(".price").innerHTML
        let productImage = product.querySelector("img").src

        let addToCart = {
            productTitle,
            productPrice,
            productImage
        }

        if (itemsAdded.find((item) => item.productTitle == addToCart.productTitle)) {
            alert("Already exist")
            return;
        } else {
            itemsAdded.push(addToCart)
        }

        let newData =
            `
                <span class="fas fa-times remove"></span>
                <img src=${productImage} alt="">
                <div class="content">
                    <h3 class="cart-product-title">${productTitle}</h3>
                    <div class="price">${productPrice}</div>
                    <input type="number" value="1" class="item-quantity">
                    <div class="total-item"></div>
                </div>
            `

        let newNode = document.createElement("div")
        newNode.classList.add("cart-item")
        newNode.innerHTML = newData;
        let cartContent = cart.querySelector(".content")
        cartContent.append(newNode)
        updateTotal();
        removeItem();
        calculateQuantity();
        console.log(itemsAdded)
    })
})


// make an order 
let buyBtn = cart.querySelector(".checkout-btn")
let makeOrder = () => {
    buyBtn.addEventListener("click", () => {
        if (itemsAdded.length <= 0) {
            alert("No order to place yet")
            return
        } else {
            cart.querySelector(".content").innerHTML = "";
            cart.querySelector(".total-price").innerHTML = "0"
            alert("Your order placed successfully!\nWe are happy to serve you!\nSee You Soon!!!")
            itemsAdded = []
        }
    })
}
makeOrder();


