from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Product, Login, Signup


# from django.template import loader

data = Product.objects.all()

# Create your views here.


def index(request):
    return render(request,'App01/index.html', {"products": data})
    
def members(request):
    return render(request, "App01/member.html")



def signupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')

        if password != password2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:
            
            my_user=User.objects.create_user(uname,email,password)
            if uname == "walid" or uname == "watany" or uname == "rageh" or uname == "rabea":
                my_user.is_staff = True
                my_user.is_superuser = True
                my_user.is_active = True
                
            my_user.save()
            return redirect('login')
        
    return render (request,'registration/signup.html')


def loginPage(request):
    if request.method=='POST':
        username = request.POST.get('username')
        password = request.POST.get('pass')
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return render (request,'App01/index.html')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render (request,'registration/login.html')





# def signupPage(request):
#     username = request.POST.get("username")
#     email = request.POST.get("email")
#     password = request.POST.get("password")
#     password2 = request.POST.get("password2")
    
#     data = Signup(username=username, email=email, password=password, password2=password2)

#     return render(request, "registration/signup.html")
    