from django.contrib import admin
from .models import Product
from .models import Login
from .models import Signup

# Register your models here.
admin.site.register(Product)
admin.site.register(Login)
admin.site.register(Signup)